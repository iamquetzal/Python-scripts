from PyQt5 import QtCore, QtGui, QtWidgets , QtWebEngineWidgets
import os
import sys
from time import sleep
from urllib.request import Request, urlopen
from multiprocessing import Pipe

class Ui_Dialog(object):
    html_tab_1 = str()
    def __init__(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1351, 622)
        Dialog.setStyleSheet(open("light.qss", "r").read())
        self.horizontalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 0, 591, 451))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.scrollArea = QtWidgets.QScrollArea(self.horizontalLayoutWidget)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtWidgets.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 587, 447))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.tabWidget = QtWidgets.QTabWidget(self.scrollAreaWidgetContents)
        self.tabWidget.setGeometry(QtCore.QRect(0, 0, 591, 451))
        self.tabWidget.setObjectName("tabWidget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.textEdit_2 = QtWebEngineWidgets.QWebEngineView(self.tab)
        self.textEdit_2.setGeometry(QtCore.QRect(-7, 0, 591, 431))
        self.textEdit_2.setObjectName("textEdit_2")
        self.verticalScrollBar_3 = QtWidgets.QScrollBar(self.tab)
        self.verticalScrollBar_3.setGeometry(QtCore.QRect(570, 0, 16, 421))
        self.verticalScrollBar_3.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_3.setObjectName("verticalScrollBar_3")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")
        self.textEdit_3 = QtWebEngineWidgets.QWebEngineView(self.tab_2)
        self.textEdit_3.setGeometry(QtCore.QRect(-7, 0, 601, 431))
        self.textEdit_3.setObjectName("textEdit_3")
        self.verticalScrollBar_2 = QtWidgets.QScrollBar(self.tab_2)
        self.verticalScrollBar_2.setGeometry(QtCore.QRect(570, -1, 20, 421))
        self.verticalScrollBar_2.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_2.setObjectName("verticalScrollBar_2")
        self.tabWidget.addTab(self.tab_2, "")
        #
        self.tab_3 = QtWidgets.QWidget()
        self.tab_3.setObjectName("tab_3")
        self.textEdit_4 = QtWebEngineWidgets.QWebEngineView(self.tab_3)
        self.textEdit_4.setGeometry(QtCore.QRect(-7, 0, 621, 431))
        self.textEdit_4.setObjectName("textEdit_4")
        self.verticalScrollBar_3 = QtWidgets.QScrollBar(self.tab_3)
        self.verticalScrollBar_3.setGeometry(QtCore.QRect(570, -1, 20, 421))
        self.verticalScrollBar_3.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_3.setObjectName("verticalScrollBar_3")
        self.tabWidget.addTab(self.tab_3, "")
        #
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.horizontalLayout.addWidget(self.scrollArea)
        self.verticalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(610, 0, 741, 551))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(1020, 560, 91, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(1120, 560, 81, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.comboBox = QtWidgets.QComboBox(Dialog)
        self.comboBox.setGeometry(QtCore.QRect(610, 560, 401, 22))
        self.comboBox.setObjectName("comboBox")
        self.scrollArea_2 = QtWidgets.QScrollArea(Dialog)
        self.scrollArea_2.setGeometry(QtCore.QRect(610, 0, 741, 551))
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollArea_2.setObjectName("scrollArea_2")
        self.scrollAreaWidgetContents_2 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_2.setGeometry(QtCore.QRect(0, 0, 739, 549))
        self.scrollAreaWidgetContents_2.setObjectName("scrollAreaWidgetContents_2")
        self.verticalScrollBar = QtWidgets.QScrollBar(self.scrollAreaWidgetContents_2)
        self.verticalScrollBar.setGeometry(QtCore.QRect(720, 0, 20, 551))
        self.verticalScrollBar.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar.setObjectName("verticalScrollBar")
        self.textEdit = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_2)
        self.textEdit.setGeometry(QtCore.QRect(0, 0, 721, 551))
        self.textEdit.setObjectName("textEdit")
        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_2)
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(Dialog)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(10, 460, 591, 121))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.scrollArea_3 = QtWidgets.QScrollArea(self.horizontalLayoutWidget_2)
        self.scrollArea_3.setWidgetResizable(True)
        self.scrollArea_3.setObjectName("scrollArea_3")
        self.scrollAreaWidgetContents_4 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_4.setGeometry(QtCore.QRect(0, 0, 587, 117))
        self.scrollAreaWidgetContents_4.setObjectName("scrollAreaWidgetContents_4")
        self.textEdit_4 = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_4)
        self.textEdit_4.setGeometry(QtCore.QRect(0, 0, 191, 121))
        self.textEdit_4.setObjectName("textEdit_4")
        self.textEdit_5 = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_4)
        self.textEdit_5.setGeometry(QtCore.QRect(203, 0, 191, 121))
        self.textEdit_5.setObjectName("textEdit_5")
        self.textEdit_6 = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_4)
        self.textEdit_6.setGeometry(QtCore.QRect(403, 0, 181, 121))
        self.textEdit_6.setObjectName("textEdit_6")
        self.verticalScrollBar_4 = QtWidgets.QScrollBar(self.scrollAreaWidgetContents_4)
        self.verticalScrollBar_4.setGeometry(QtCore.QRect(170, 0, 21, 160))
        self.verticalScrollBar_4.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_4.setObjectName("verticalScrollBar_4")
        self.verticalScrollBar_5 = QtWidgets.QScrollBar(self.scrollAreaWidgetContents_4)
        self.verticalScrollBar_5.setGeometry(QtCore.QRect(380, 0, 16, 160))
        self.verticalScrollBar_5.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_5.setObjectName("verticalScrollBar_5")
        self.verticalScrollBar_6 = QtWidgets.QScrollBar(self.scrollAreaWidgetContents_4)
        self.verticalScrollBar_6.setGeometry(QtCore.QRect(570, 0, 16, 160))
        self.verticalScrollBar_6.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar_6.setObjectName("verticalScrollBar_6")
        self.scrollArea_3.setWidget(self.scrollAreaWidgetContents_4)
        self.horizontalLayout_2.addWidget(self.scrollArea_3)

        self.retranslateUi(Dialog)
        self.tabWidget.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Competitive Programming Interface"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("Dialog", "CodeForces"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("Dialog", "Codechef"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), _translate("Dialog", "Problem List"))
        self.pushButton.setText(_translate("Dialog", "Compile+ Run"))
        self.pushButton_2.setText(_translate("Dialog", "Submit"))
        self.from_loopback,self.to_loopback=Pipe(False)
        
    def loadthepages(self):
        #self.textEdit_2.load(QtCore.QUrl("https://codeforces.com/"))
        self.textEdit_3.loadFinished.connect(lambda : self.printurl(self.textEdit_3))
        self.textEdit_3.load(QtCore.QUrl("https://codechef.com/"))
        self.__nav__()
    def __nav__(self):
        pass
        #self.textEdit_2.loadFinished.connect(lambda : self.printurl(self.textEdit_2))
        #self.textEdit_3.loadFinished.connect(lambda : self.printurl(self.textEdit_3))
        #self.textEdit_3.urlChanged.connect(lambda : self.printurl(self.textEdit_3))



    def store(self,data):
        self.html = data
        
    def printurl(self,obj):

        print("from Here------------------------------")
        self.p = obj.page()
        self.p.toHtml()
        #self.resp = request.urlopen(obj.url().toString())
        #self.resp = Request ( "https://codechef.com/",headers={'User-Agent': 'Mozilla/5.0'} )
        print ( "OK" )
        #html = urlopen(self.resp).read().decode("UTF-8")
        print(self.html)
        #self.html_tab_1 = None

        
    
        


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog(Dialog)
    #ui.setupUi(Dialog)
    Dialog.show()
    ui.loadthepages()
    sys.exit(app.exec_())


'''
def render(url):
    """Fully render HTML, JavaScript and all."""

    import sys
    from PyQt5.QtCore import QEventLoop,QUrl
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtWebEngineWidgets import QWebEngineView

    class Render(QWebEngineView):
        def __init__(self, url):
            self.html = None
            self.app = QApplication(sys.argv)
            QWebEngineView.__init__(self)
            self.loadFinished.connect(self._loadFinished)
            self.load(QUrl(url))
            while self.html is None:
                self.app.processEvents(QEventLoop.ExcludeUserInputEvents | QEventLoop.ExcludeSocketNotifiers | QEventLoop.WaitForMoreEvents)
            self.app.quit()

        def _callable(self, data):
            self.html = data

        def _loadFinished(self, result):
            self.page().toHtml(self._callable)

    return Render(url).html

'''

#print(render("https://www.codechef.com/MAY19B/problems/REDONE"))






