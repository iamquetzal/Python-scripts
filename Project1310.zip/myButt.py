from PyQt5.QtWidgets import QPushButton
from PyQt5.QtCore import QRect, QPropertyAnimation , QSequentialAnimationGroup,QSize

class myButton(QPushButton):
    gexecuted=False
    def __init__(self,obj):
        super().__init__(obj)
        self.__funct__()
    def __funct__(self):
        self.clicked.connect(self.doAnimation)
    def finalgeometry(self):
        self.gexecuted = True
        self.xx,self.yy,self.x1,self.y1 = self.geometry().x(),self.geometry().y(),self.geometry().width(),self.geometry().height()
    def doAnimation(self):
        if not self.gexecuted:self.finalgeometry()
        self.anim = QPropertyAnimation(self, b"geometry")
        self.anim.setStartValue(QRect(self.xx, self.yy, self.x1,self.y1))
        self.anim.setEndValue(QRect(self.xx+10,self.yy-20,self.x1-20,self.y1+40))
        self.anim1 = QPropertyAnimation(self, b"geometry")
        self.anim1.setStartValue(QRect(self.xx+10,self.yy-20,self.x1-20,self.y1+40))
        self.anim1.setEndValue(QRect(self.xx-20,self.yy+10,self.x1+40,self.y1-10))
        self.anim2 = QPropertyAnimation(self, b"geometry")
        self.anim2.setStartValue(QRect(self.xx-20,self.yy+10,self.x1+40,self.y1-10))
        self.anim2.setEndValue(QRect(self.xx+5,self.yy-2,self.x1-10,self.y1+2))
        self.anim3 = QPropertyAnimation(self, b"geometry")
        self.anim3.setStartValue(QRect(self.xx+5,self.yy-2,self.x1-10,self.y1+2))
        self.anim3.setEndValue(QRect(self.xx-20,self.yy+10,self.x1+40,self.y1-10))
        self.anim4 = QPropertyAnimation(self, b"geometry")
        self.anim4.setStartValue(QRect(self.xx-20,self.yy+10,self.x1+40,self.y1-10))
        self.anim4.setEndValue(QRect(self.xx,self.yy,self.x1,self.y1))
        self.group = QSequentialAnimationGroup()
        self.group.addAnimation(self.anim)
        self.group.addAnimation(self.anim1)
        self.group.addAnimation(self.anim2)
        self.group.addAnimation(self.anim3)
        self.group.addAnimation(self.anim4)
        self.group.start()
        
    
