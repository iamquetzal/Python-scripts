from PyQt5 import QtWidgets,QtCore,QtWebEngineWidgets
class Widget(QtWidgets.QWidget):
    toHtmlFinished = QtCore.pyqtSignal()

    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setLayout(QtWidgets.QVBoxLayout())
        self.web_view = QtWebEngineWidgets.QWebEngineView(self)
        self.web_view.load(QtCore.QUrl("https://www.codechef.com/"))
        btn = QtWidgets.QPushButton("Get HTML", self)
        self.layout().addWidget(self.web_view)
        self.layout().addWidget(btn)
        btn.clicked.connect(self.get_html)
        self.html = ""
        self.web_view.loadFinished.connect(self.get_html)

    def store_html(self, html):
        self.html = html
        self.toHtmlFinished.emit()

    def get_html(self):
        print("OK")
        current_page = self.web_view.page()
        current_page.toHtml(self.store_html)
        loop = QtCore.QEventLoop()
        self.toHtmlFinished.connect(loop.quit)
        loop.exec()
        print(self.html)


if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    w = Widget()
    w.show()
    sys.exit(app.exec_())
